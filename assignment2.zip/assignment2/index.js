// I'm importing the Express.js framework, which I'll use to create a web server.
import express from 'express';

// I'm importing the routes module, which defines the routes for my application.
import routes from './routes/routes.js';

// I'm importing the path module, which provides utilities for working with file paths.
import path from 'path';

// I'm creating a new instance of the Express app, which will be the core of my web server.
const app = express();

// I'm setting the port number for my server. If an environment variable called PORT is set, I'll use that value; otherwise, I'll default to port 8000.
const port = process.env.PORT || 8000;

// I'm setting up Express to serve static files from the 'public' directory. I'm using the path.join function to construct the full path to the 'public' directory, relative to the current working directory.
app.use(express.static(path.join(process.cwd(), 'public')));

// I'm setting up Express to use the EJS templating engine for rendering views. I'm telling Express to look for view templates in the './views' directory.
app.set('view engine', 'ejs');
app.set('views', './views');

// I'm mounting the routes defined in the routes module to the root URL ('/') of my application.
app.use('/', routes)

// I'm starting the server and listening on the specified port. When the server is running, I'll log a message to the console indicating the port number.
app.listen(port, () => {
    console.log(`server is running on port ${port}`);
})

