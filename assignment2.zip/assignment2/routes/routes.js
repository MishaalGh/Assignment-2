// I'm importing the Express.js framework, which I'll use to create a web server.
import express from 'express';

// I'm importing the homeController function from a separate file called homeController.js.
// This function will handle requests to the root URL ('/') of my application.
import { homeController } from '../controllers/homeController.js';

// I'm creating a new instance of the Express Router, which will allow me to define routes for my application.
const routes = express.Router();

// I'm defining a GET route for the root URL ('/'). When this route is requested, I'll call the homeController function to handle the request.
routes.get('/', homeController);

// I'm exporting the routes instance as the default export of this module, so it can be imported and used in other parts of my application.
export default routes;