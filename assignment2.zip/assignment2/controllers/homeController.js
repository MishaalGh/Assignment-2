// I'm defining a controller function called homeController, which will handle requests to the root URL ('/') of my application.
const homeController = (req, res) => {
    // When this function is called, I'll render the 'index' view template and send the resulting HTML as the response to the client.
    // I'm using the res.render method provided by Express, which will look for a view template called 'index' in the directory specified by the file name 'views' setting (which I set to './views' earlier).
    res.render('index')
}

// I'm exporting the homeController function as a module, so it can be imported and used in other parts of my application.
export { homeController }